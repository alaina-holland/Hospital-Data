import pandas as pd
import json

with open('kadlec_standardcharges.json') as fh:
	data = json.load(fh)

for key in data:
	df = pd.read_json(json.dumps(data[key]))
	df.to_csv(key + '.csv', index=False)
